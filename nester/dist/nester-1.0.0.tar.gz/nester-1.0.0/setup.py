#!/usr/bin/env python

from distutils.core import setup


setup(
        name         = 'nester',
        version      = '1.0.0',
        py_modules   = ['nester'],
        author       = 'moonlight',
        author_email = '519435155@qq.com',
        url          = '',
        description  = 'A simple printer of nested lists',
        )
